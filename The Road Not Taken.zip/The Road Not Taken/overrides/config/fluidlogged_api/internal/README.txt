Everything in this folder was automatically downloaded from
https://github.com/jbredwards/Fluidlogged-API-Configs.

This functionality can be disabled in Fluidlogged API's general.cfg file. 
Everything in this folder can be safely excluded from modpack uploads to reduce file size.

WARINING: This folder's contents should not be manually edited. There's nothing stopping you,
but any edits to this folder's contents will be overriden if the community configs ever change.
If there are any specific blocks that you'd like to add or remove, you should edit the deticated
configs/fluidlogged_api/whitelist.cfg and configs/fluidlogged_api/blacklist.cfg files instead.

If you would like to see more community configs, or would like to contribute your own configs for
other people to use, create an issue or pull request at https://github.com/jbredwards/Fluidlogged-API-Configs!